// simplified controller
public class ProductsController{}